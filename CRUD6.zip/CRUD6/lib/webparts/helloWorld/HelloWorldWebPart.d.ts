import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import "@pnp/sp/lists";
import "@pnp/sp/items";
export interface IHelloWorldWebPartProps {
    description: string;
}
export default class HelloWorldWebPart extends BaseClientSideWebPart<IHelloWorldWebPartProps> {
    render(): Promise<void>;
    getHTML(): Promise<string>;
    protected readonly dataVersion: Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
export declare const getChoiceFields: (webURL: any) => Promise<any[]>;
export declare const checkStatus: (value: any) => string;
//# sourceMappingURL=HelloWorldWebPart.d.ts.map