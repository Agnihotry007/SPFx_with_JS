/* tslint:disable */
require("./HelloWorldWebPart.module.css");
const styles = {
  helloWorld: 'helloWorld_8e7af645',
  container: 'container_8e7af645',
  row: 'row_8e7af645',
  column: 'column_8e7af645',
  'ms-Grid': 'ms-Grid_8e7af645',
  title: 'title_8e7af645',
  subTitle: 'subTitle_8e7af645',
  description: 'description_8e7af645',
  button: 'button_8e7af645',
  label: 'label_8e7af645',
  table: 'table_8e7af645',
  borderset: 'borderset_8e7af645'
};

export default styles;
/* tslint:enable */